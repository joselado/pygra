import geometry  # library to create crystal geometries
import hamiltonians  # library to work with hamiltonians
import input_tb90 as in90
import heterostructures
import sys
import sculpt  # to modify the geometry
import numpy as np
import klist
import pylab as py
import green
import interactions
import heterostructures


g = geometry.square_ribbon(4) # create geometry of the system
h = hamiltonians.hamiltonian(g) # create hamiltonian
h.first_neighbors()  # create first neighbor hopping


es = np.linspace(-3.,3.,100) # array with the energies

hlist = [h for i in range(10)]  # create a list with the hamiltonians 
                                # of the scattering centrl part
# create a junction object
ht = heterostructures.create_leads_and_central_list(h,h,hlist) 

# calculate transmission
figt = ht.plot_landauer(energy=es,delta=0.00001)  # figure with the transmission
figb = h.plot_bands(nkpoints=300)  # figure with the bands
py.show()
