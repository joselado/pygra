import numpy as np

def integrate_matrix2d(f,xlim,ylim):
  """ Performs a montecarlo integration for a 2d matrix,
      f is a function which yields the matrix"""



