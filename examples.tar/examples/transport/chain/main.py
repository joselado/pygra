import geometry
import heterostructures

g = geometry.chain()
h = g.get_hamiltonian()
h.remove_spin()

ht = heterostructures.create_leads_and_central(h,h,h)



