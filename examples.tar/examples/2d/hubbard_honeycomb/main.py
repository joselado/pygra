import geometry
import numpy as np
import scftypes

g = geometry.honeycomb_lattice() # create geometry of a chain
n = 3
g = g.supercell(n)

h = g.get_hamiltonian() # get the Hamiltonian

mag = [[0.,0.,1.],[0.,0.,-1.]]*n**2 # initial guess for the magnetization
scf = scftypes.hubbardscf(h,U=3.0,nkp=10,filling=0.5,mag=mag,silent=True) # perform scf
scf.hamiltonian.write()  # write the Hamiltonian


# Magnetization is written in MAGNETIZATION.OUT
# Positions are written in POSITIONS.OUT
