# zigzag ribbon
import sys
sys.path.append("../../../pygra")  # add pygra library

import geometry
import topology
g = geometry.chain() # create geometry of a chain
h = g.get_hamiltonian(has_spin=True) # get the Hamiltonian, spinfull
h.add_rashba(0.5) # add Rashba SOC
h.add_zeeman(0.3) # add Zeeman field
h.shift_fermi(2.) # add Zeeman field
h.add_swave(0.1) # add swave pairing

phi = topology.berry_phase(h) # get the berry phase
print(phi)
hf = h.supercell(500) # do a supercell
hf = hf.set_finite_system(periodic=False) # do an open finite system
hf.get_bands()
