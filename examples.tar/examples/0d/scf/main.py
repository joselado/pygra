
sys.path.append("../../../pygra")  # add pygra library
import sys
import islands
import interactions

g = islands.get_geometry(name="honeycomb",n=3) # get an island
h = g.get_hamiltonian() # get the Hamiltonian
g.write()
