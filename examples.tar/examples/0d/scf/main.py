
import sys
sys.path.append("../../../pygra")  # add pygra library
import islands

g = islands.get_geometry()
g.write()
