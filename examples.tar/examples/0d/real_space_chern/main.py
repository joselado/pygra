
import sys
sys.path.append("../../../pygra")  # add pygra library
import islands
import densitymatrix
import numpy as np
import time


g = islands.get_geometry(name="honeycomb",n=4,clean=False) # get an island
h = g.get_hamiltonian() # get the Hamiltonian
g.write()

t1 = time.clock()
dm = densitymatrix.get_dm(h,use_fortran=False)
t2 = time.clock()
dmf = densitymatrix.get_dm(h,use_fortran=True)
t3 = time.clock()
print("Error = ",np.sum(np.abs(dm-dmf)))
print("Time Fortran = ",t3-t2)
print("Time Python = ",t2-t1)

